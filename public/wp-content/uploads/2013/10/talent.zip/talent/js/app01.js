var camera, scene, renderer;
var ambientLight, directionalLight;
var controls;
var cube = new Array(); // 配列の各要素をグローバル変数として扱う必要がある
	
init();// 初期化
animate();// アニメーション開始

function init() {

    // シーンを作る
    scene = new THREE.Scene();

    // カメラ設定
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 1, 5000);
    camera.position.z = 1000;

    // add subtle ambient lighting
    var ambientLight = new THREE.AmbientLight(0x111144);
    scene.add(ambientLight);
      
    // directional lighting
    var directionalLight = new THREE.DirectionalLight(0xffffff,4);
    directionalLight.position.set(1, 1, 1).normalize();
    scene.add(directionalLight);

    // SVGオブジェクトの貼り付け
    var geometry = new THREE.PlaneGeometry(1180, 900, 1, 1);

	var imageCanvas2 = document.createElement("canvas");
    canvg(imageCanvas2, 'talent2013s.svg');
    var texture = new THREE.Texture(imageCanvas2);
    texture.needsUpdate = true;
    var material = new THREE.MeshBasicMaterial({
		map: texture
	});

	var mesh = new THREE.Mesh(geometry, material);
	scene.add(mesh);
	
	// ３次元棒グラフの挿入
	var scale = 0.58;
	var paddingX = -25;
	var paddingY = 10;	

    for (key in graph["nodes"]) {
		console.log(key);
		var material = new THREE.MeshLambertMaterial({color:graph["nodes"][key]["color"], transparent: true });
		var likes = parseFloat((graph["nodes"][key]["attributes"]["Mean"])-1) * 100;
		material.opacity = 0.7;
		cube[key] = new THREE.Mesh(new THREE.CubeGeometry(10,10,likes), material);
		scene.add(cube[key]);
		cube[key].position.set(graph["nodes"][key]["x"]*scale - paddingX,graph["nodes"][key]["y"]*scale - paddingY, 0);
		cube[key].scale.z = 1.0;
	}
	
    // レンダラー
    renderer = new THREE.WebGLRenderer();
	// renderer = new THREE.CSS3DRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight); // 描画領域
    renderer.domElement.style.position = 'absolute'; // スタイル設定 {position:absolute}
    document.getElementById('container').appendChild(renderer.domElement); // 描画領域を#containerにappend

    // カメラコントローラー
    controls = new THREE.TrackballControls(camera, renderer.domElement);
    controls.rotateSpeed = 0.5; // 感度設定
    controls.addEventListener('change', render); // 値が変わった（マウスで何か位置が変更された）ときに render() を呼び出す


    // #aがクリックされたアニメーション
    $("#a").click(function () {
		transform(0.2,2000);
    });

    // #bがクリックされたアニメーション
    $("#b").click(function () {
		transform(1.0,2000);
    });

    // #cがクリックされたアニメーション
    $("#c").click(function () {
		transform(2.0,2000);
    });

    //ウィンドウリサイズ時、onWindowResize()を呼び出す
    window.addEventListener('resize', onWindowResize, false);
}

function onWindowResize() {
    // カメラ設定
    camera.aspect = window.innerWidth / window.innerHeight; // カメラの縦横比を再設定
    camera.updateProjectionMatrix(); // 更新
    renderer.setSize(window.innerWidth, window.innerHeight); // レンダリングサイズを再設定
}


function transform(scale, duration) {
	
    TWEEN.removeAll(); // TWEEN処理が混在しないように一旦全て中止

    // メソッドチェーン最後尾のstart()でアニメーションを開始しています。
	for (key in graph["nodes"]) {
	    // アニメーション処理
    	new TWEEN.Tween(cube[key].scale) 
        	.to({ z: scale }, duration) // スケールと所要時間
        	.easing(TWEEN.Easing.Exponential.InOut) // アニメーションパターン
        	.start(); // 設定が住んだら開始!!

 	   // フレーム描画処理
    	new TWEEN.Tween(this)
        	.to({}, duration)
        	.onUpdate(render)
        	.start();
	}
}

/* ループ
requestAnimationFrameでフレームアニメーション化してTWEENとcontrolsを更新。
*/

function animate() {
    TWEEN.update(); // tween更新
    controls.update(); // 位置更新
	requestAnimationFrame(animate); // three.js 内関数
}

// TWEENでアニメーションする際に呼び出される
function render() {
    renderer.render(scene, camera);
}