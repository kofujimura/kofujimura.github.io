var camera, scene, renderer;
var ambientLight, directionalLight;
var controls, object;

init();// 初期化
animate();// アニメーション開始

function init() {

    // シーンを作る
    scene = new THREE.Scene();

    // カメラ設定
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 1, 5000);
    camera.position.z = 1000;

    // add subtle ambient lighting
    var ambientLight = new THREE.AmbientLight(0x111144);
    scene.add(ambientLight);
      
    // directional lighting
    var directionalLight = new THREE.DirectionalLight(0xffffff,4);
    directionalLight.position.set(1, 1, 1).normalize();
    scene.add(directionalLight);

    // SVGオブジェクトの貼り付け
    var geometry = new THREE.PlaneGeometry(1180, 900, 1, 1);

	var imageCanvas2 = document.createElement("canvas");
    canvg(imageCanvas2, 'talent2013s.svg');
    var texture = new THREE.Texture(imageCanvas2);
    texture.needsUpdate = true;
    var material = new THREE.MeshBasicMaterial({
		map: texture
	});

	var mesh = new THREE.Mesh(geometry, material);
	scene.add(mesh);	
	
	
	// センターcube
	material = new THREE.MeshLambertMaterial({color:"blue"});
	object = new THREE.Mesh(new THREE.CubeGeometry(100,100,100), material);
	scene.add(object);
	object.position.set(99,88,77);
	
	
	// ３次元棒グラフの挿入
	var scale = 0.58;
	var paddingX = -25;
	var paddingY = 10;
	var paddingZ = 0;	
	var cube = new Array();
    for (key in graph["nodes"]) {
		var material = new THREE.MeshLambertMaterial({color:graph["nodes"][key]["color"], transparent: true });
		var likes = parseFloat(graph["nodes"][key]["attributes"]["Mean"])*40;
		material.opacity = 0.8;
		cube[key] = new THREE.Mesh(new THREE.CubeGeometry(20,20,likes), material);
		scene.add(cube[key]);
		cube[key].position.set(graph["nodes"][key]["x"]*scale - paddingX,graph["nodes"][key]["y"]*scale - paddingY, likes * 0.5);
	}
	
    // レンダラー
    renderer = new THREE.WebGLRenderer();
	// renderer = new THREE.CSS3DRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight); // 描画領域
    renderer.domElement.style.position = 'absolute'; // スタイル設定 {position:absolute}
    document.getElementById('container').appendChild(renderer.domElement); // 描画領域を#containerにappend

    // カメラコントローラー
    controls = new THREE.TrackballControls(camera, renderer.domElement);
    controls.rotateSpeed = 0.5; // 感度設定
    controls.addEventListener('change', render); // 値が変わった（マウスで何か位置が変更された）ときに render() を呼び出す

    // 座標＆回転設定 A
    var targetA = new THREE.Object3D();

    // 座標＆回転設定 B
    var targetB = new THREE.Object3D();
    targetB.position.y = 300;
    targetB.rotation.x = 3.14;

    // 座標＆回転設定 C
    var targetC = new THREE.Object3D();
    targetC.position.y = 100;
    targetC.position.z = 500;
    targetC.rotation.x = 1;
    targetC.rotation.y = 2;
    targetC.rotation.z = 3;

    // // #aがクリックされたら 設定A 方向にアニメーション
    $("#a").click(function () {
        transform(targetA, 1000);
    });

    // // #aがクリックされたら 設定B 方向にアニメーション
    $("#b").click(function () {
        transform(targetB, 1000);
    });

    // // #aがクリックされたら 設定C 方向にアニメーション
    $("#c").click(function () {
        transform(targetC, 1000);
    });

    //ウィンドウリサイズ時、onWindowResize()を呼び出す
    window.addEventListener('resize', onWindowResize, false);
}

function onWindowResize() {
    // カメラ設定
    camera.aspect = window.innerWidth / window.innerHeight; // カメラの縦横比を再設定
    camera.updateProjectionMatrix(); // 更新
    renderer.setSize(window.innerWidth, window.innerHeight); // レンダリングサイズを再設定
}

function transform(target, duration) {

    TWEEN.removeAll(); // TWEEN処理が混在しないように一旦全て中止

    /*
    下記は座標と回転の2つに分けてアニメーション情報を設定し、
    メソッドチェーン最後尾のstart()でアニメーションを開始しています。
    */

    // 座標アニメーション処理
    new TWEEN.Tween(object.position) // object（0,0)のposition情報を使って座標アニメーションさせますよ
        .to({ x: target.position.x, y: target.position.y, z: target.position.z }, duration) // x,y,z移動先と所要時間
        .easing(TWEEN.Easing.Exponential.InOut) // アニメーションパターン
        .start(); // 設定が住んだら開始!!

    // 回転アニメーション処理
    new TWEEN.Tween(object.rotation) // object（0,0)のposition情報を使って回転アニメーションさせますよ
        .to({ x: target.rotation.x, y: target.rotation.y, z: target.rotation.z }, duration) // x,y,z回転と所要時間
        .easing(TWEEN.Easing.Exponential.InOut) // アニメーションパターン
        .start(); // 設定が住んだら開始!!

    // フレーム描画処理
    new TWEEN.Tween(this)
        .to({}, duration)
        .onUpdate(render)
        .start();
}

/* ループ
requestAnimationFrameでフレームアニメーション化して
TWEENとcontrolsを更新しています。
これは決まり文句的なものです
*/

function animate() {
    TWEEN.update(); // tween更新
    controls.update(); // 位置更新
	requestAnimationFrame(animate); // three.js 内関数
}

// TWEENでアニメーションする際に呼び出される
function render() {
    renderer.render(scene, camera);
}